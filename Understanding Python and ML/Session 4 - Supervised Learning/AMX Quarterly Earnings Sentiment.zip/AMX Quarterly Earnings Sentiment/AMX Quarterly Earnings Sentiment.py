
# Supervised Learning

"""
The objective of this code is to crete a sentiment tool for quarterly earnings reports.
"""

# Libraries

import re
import nltk
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import load_files
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# Functions

def Text_cleaner(text):
    
    'Remove all special characters'
    document = re.sub(r'\W',' ',str(text))
    
    'Remove all the single characters'
    document = re.sub(r'\s+[a-zA-Z]\s+',' ', document)
    
    'Remove single characters from the start'
    document = re.sub(r'\^[a-zA-Z]\s+',' ', document)
    
    'Remove all the things diferent of abcd...zABC...Z and puts a space'
    document = re.sub('[^a-zA-Z]', ' ', document)
    
    'Replace multiple spaces with single space'
    document = re.sub(r'\s+',' ', document, flags=re.I)
 
    'Remove prefixed b'
    document = re.sub(r'^b\s+',' ',document)
    
    'Converting to lowercase'
    document = document.lower()
 
    'Split the document in a list of words'
    document = document.split()

    'Creates a list of words'
    document = [stemmer.lemmatize(word) for word in document]
    
    'Joins all that words with spaces'
    document = ' '.join(document)
    
    'Returns the new document'
    return document

def Vect_creation(documents,stop_words,max = 20,min = 5,df =0.7):
    """
    We want to use the 100 most occurring words for traning the clasifier
    5 is the minimum number of documents that should contain this feature
    0.7 means we should include words that occur in a max of 70% of all documents
    Finally we remove the stopwords.
    """
    tfidfconverter = TfidfVectorizer(max_features=max, min_df=min, max_df=df, stop_words=stopwords)
    
    'Converts  text documents into corresponding numeric features'
    X = tfidfconverter.fit_transform(documents).toarray()
    return X

# Main Program

'Loads the data'
earnings_data = load_files("txt_sentoken")

'We define the stopwords'
stopwords = ['de','la','que','el','en','y','a','los','del','se','las','por',
             'un','para','con','no','una','su','al','lo','como','más','pero',
             'sus','le','ya','o','este','sí','porque','esta','entre','cuando',
             'muy','sin','sobre','también','me','hasta','hay','donde','quien',
             'desde','todo','nos','durante','todos','uno','les','ni','contra',
             'otros','ese','eso','ante','ellos','e','esto','mí','antes',
             'algunos','qué','unos','yo','otro','otras','otra','él','tanto',
             'esa','estos','mucho','quienes','nada','muchos','cual','poco',
             'ella','estar','estas','algunas','algo','nosotros','mi','mis',
             'tú','te','ti','tu','tus','ellas','nosotras','vosotros',
             'vosotras','os','mío','mía','míos','mías','tuyo','tuya','tuyos',
             'tuyas','suyo','suya','suyos','suyas','nuestro','nuestra',
             'nuestros','nuestras','vuestro','vuestra','vuestros','vuestras',
             'esos','esas','estoy','estás','está','estamos','estáis','están',
             'esté','estés','estemos','estéis','estén','estaré','estarás',
             'estará','estaremos','estaréis','estarán','estaría','estarías',
             'estaríamos','estaríais','estarían','estaba','estabas',
             'estábamos','estabais','estaban','estuve','estuviste','estuvo',
             'estuvimos','estuvisteis','estuvieron','estuviera','estuvieras',
             'estuviéramos','estuvierais','estuvieran','estuviese',
             'estuvieses','estuviésemos','estuvieseis','estuviesen','estando',
             'estado','estada','estados','estadas','estad','he','has','ha',
             'hemos','habéis','han','haya','hayas','hayamos','hayáis','hayan',
             'habré','habrás','habrá','habremos','habréis','habrán','habría',
             'habrías','habríamos','habríais','habrían','había','habías',
             'habíamos','habíais','habían','hube','hubiste','hubo','hubimos',
             'hubisteis','hubieron','hubiera','hubieras','hubiéramos',
             'hubierais','hubieran','hubiese','hubieses','hubiésemos',
             'hubieseis','hubiesen','habiendo','habido','habida','habidos',
             'habidas','soy','eres','es','somos','sois','son','sea','seas',
             'seamos','seáis','sean','seré','serás','será','seremos','seréis',
             'serán','sería','serías','seríamos','seríais','serían','era',
             'eras','éramos','erais','eran','fui','fuiste','fue','fuimos',
             'fuisteis','fueron','fuera','fueras','fuéramos','fuerais',
             'fueran','fuese','fueses','fuésemos','fueseis','fuesen',
             'sintiendo','sentido','sentida','sentidos','sentidas','siente',
             'sentid','tengo','tienes','tiene','tenemos','tenéis','tienen',
             'tenga','tengas','tengamos','tengáis','tengan','tendré','tendrás',
             'tendrá','tendremos','tendréis','tendrán','tendría','tendrías',
             'tendríamos','tendríais','tendrían','tenía','tenías','teníamos',
             'teníais','tenían','tuve','tuviste','tuvo','tuvimos','tuvisteis',
             'tuvieron','tuviera','tuvieras','tuviéramos','tuvierais',
             'tuvieran','tuviese','tuvieses','tuviésemos','tuvieseis',
             'tuviesen','teniendo','tenido','tenida','tenidos','tenidas','tened',
             'e','c','f','\n','banco','t','j','i','ii','iii','n','l','d',
             'm','a','grafica','enero','febrero','marzo','abril','mayo',
             'junio','exico','julio','agosto','septiembre','octubre',
             'noviembre','diciembre','ene','feb','mar','abr','may','jun',
             'jul','ago','sep','oct','nov','dic','anual','informe',
             'trimestral', 'fuente', 'exico','trimestre', 'fuente','mexico',
             'linea','trimestres','fuentes','balances','utiliza',
             'informaciondisponible','determinantes','incluyendo',
             'disponible','informacion','proceso','solida','punteada',
             'erepresenta','primera','primer','media','movil','trim',
             'general','cuadro','anterior','actual','abanico','por','ciento',
             'p','pp','determinacion','u','v','h','g','z','r','k','y','o',
             'aa','aaa','ademas','anco','ano','anos','aproximadamente','arzo',
             'asi','asimismo','aun','aunque','aunado','b','cabe','cada','dar',
             'dara','decir','dia','dias','dicha','dichas','dicho','dichos',
             'dio','doce','dos','tres','ello','embargo','fecha','haber',
             'habia','habian','habiendose','hace','hacer','hacia','hecho',
             'hizo','incluir','incluso','incluye','inicia','inicialmente',
             'inicio','iv','jp','lugar','muestra','nero','obvia','parece',
             'pesar','pese','s','seccion','segun','segunda','segundo','seis',
             'si','sido','sino','tal','total','totales','traduce','traduciria',
             'traves','unidos','unicamente','x','bb','bbb','bbc','bc','bce',
             'bea','bls','cbp','ccm','cds','comportamiento','conlleva',
             'consecuencia','contexto','contraste','correspondiente',
             'correspondientes','cuales','cualquier','cuanto','cuarto',
             'cuatro','curva','curvas','dato','datos','debe','debido',
             'diversas','diversos','efecto','efectos','eje','ejemplo',
             'ejercen','ejercicio','elaboracion','elaborada','elaborado',
             'elaborados','encuentran','encuesta','encuestados','encuestas',
             'er','final','finales','graficas','historicamente','historico',
             'imor','imora','intervalo','intervalos','manera','mes','meses',
             'nota','notar','notas','observa','observacion','observaciones',
             'observada','observadas','observado','observados','observan',
             'observando','observarse','observe','observen','observo',
             'obstante','partir','pasado','pasando','pasar','pasaron',
             'periodo','periodos','podria','podrian','previamente','revias',
             'previo','previos','q','quincena','quincenal','recuadro',
             'referencia','referenciado','referencias','referida','referido',
             'referidos','refiere','refieren','repuntar','repuntaron',
             'repunte','repunto','respecta','respectivamente','respectivos',
             'respecto','siglas','sistema','tales','ventana','ventas','ver',
             'vi','vias','www','tercer','parte','w','ma','particular',
             'nforme','particular','ea','oea','abcd','inflacion','precio','precios',
             'millones','pesos','mil','miles','america','dolares']

'X is a list of strings type elements where each element corresponds to a transcript'
'y is a numpy array of size n of 0s and 1s.'
X,y = earnings_data.data, earnings_data.target

'Empty list'
documents = []

'Object used in the next steps for lemmatize'
stemmer = WordNetLemmatizer()

'For each transcript in X:'
for sen in range(0, len(X)):
    'Remove all special characters'
    document = Text_cleaner(X[sen])
    'Creates a list of documents'
    documents.append(document)

'Creates the vectors'
X = Vect_creation(documents,stopwords,100,5,0.7)

'Divides data into 20% test set and 80% training set'
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.2, random_state=0)

'Train our machine learning model using the random forest algorithm'
classifier = RandomForestClassifier(n_estimators=1000, random_state=0)
classifier.fit(X_train, y_train)

# Test the model

y_pred = classifier.predict(X_test)
print("""======================================================================
Confution Matrix:
                          positive                 negative
 positive   [positive classified as positive, positive classified as negative ]  
 negative   [negative classified as positive, negative classified as negative ]

For this model:
    """)
print(confusion_matrix(y_test,y_pred),"\n")
print("======================================================================")
print("Model Report:")
print("""Precision: The accuracy of the positive predictions
recall: Ratio of positive instances that are correctly detected by the classifier.
F1-Score: Is the harmonic mean of precision and recall. The harmonic mean gives much more weight to low values.
As a result, the classifier will only get a high F1 score if both recall and precision are high.""")
print(classification_report(y_test,y_pred))
print("Acuracy pct: ",round(accuracy_score(y_test,y_pred)*100,2),"%\n")
print("======================================================================")

'Read the file'
report = str(input("Write the report to analize: \n(ex. 2019_4): "))
Test = earn_data = open(r"AMX_txt\\" + str(report)+ ".txt","rb").read()

'Puts the text in a list just because is a requirement'
Txt = [ Text_cleaner(Test) ]

'Creates the vector for that text'
test = Vect_creation(Txt,stopwords,100,0,1)

'Predict the sentiment that you want from the given document'
y_pred = classifier.predict(test)

'Print the results'
if y_pred==[0]:
    print("\nIt is expected that the action will go DOWN on the next quarter.")
if y_pred==[1]:
    print("\nIt is expected that the action will go UP on the next quarter.")
