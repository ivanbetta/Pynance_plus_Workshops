
Redy to run!

For instructions please check this video: https://www.youtube.com/watch?v=VyuDiqcg4ik&feature=youtu.be and Supervised Learning pdf

Enjoy!
