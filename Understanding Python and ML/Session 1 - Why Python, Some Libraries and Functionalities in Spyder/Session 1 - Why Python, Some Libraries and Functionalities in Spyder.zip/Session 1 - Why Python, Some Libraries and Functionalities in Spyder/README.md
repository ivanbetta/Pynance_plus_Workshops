Redy to run!

For instructions please check this video:
https://www.youtube.com/watch?v=OSjRZvAU3bM&feature=youtu.be and Why Python... pdf

Enjoy!
