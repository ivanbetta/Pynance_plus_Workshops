
# News Sentiment

"""
The objective of this code is train a model wiht some supervised algorithms and the S&P 500 performance
to create buy/sell signals.
"""

# Libraries

import nltk
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pandas_datareader.data as web
from sklearn import metrics
from datetime import timedelta
from dateutil.parser import parse
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import cross_val_score
from nltk.sentiment.vader import SentimentIntensityAnalyzer
nltk.download('vader_lexicon')

# Main

analyzer = SentimentIntensityAnalyzer()
csv_file1 = pd.read_csv('reuters_headlines.csv')
csv_file1['Date'] = csv_file1['Time'].map(parse)
csv_file2 = pd.read_csv('guardian_headlines.csv')
csv_file2['Date'] = csv_file2['Time'].map(parse)
csv_file3 = pd.read_csv('cnbc_headlines.csv')
csv_file3 = csv_file3.dropna()
csv_file3['Date'] = csv_file3['Time'].map(parse)
csv_file3['Date'] = [  time.replace(minute=0, hour=0, second=0, microsecond=0) for time in csv_file3['Date'] ]

# Reading different files to add them into our news dataframe

News = pd.concat( [csv_file1, csv_file2, csv_file3] )
News = News[['Date','Headlines']]
News = News.sort_values(by='Date', ascending= False)
News['Sentiment']=0

# Preparing to calculate the sentiment of each headline

sizen=np.arange(len(News))
News=News.set_index(sizen)
score_values = []
for i in range(len(News)):
    vs1 = analyzer.polarity_scores(str(News['Headlines'][i]))
    print(i," Score: " + str(vs1))
    score_values.append(vs1)

sentiment_scores = pd.DataFrame(score_values)
News = pd.merge(News, sentiment_scores, left_index=True, right_index=True)
senti=[]
dates=News['Date']
dates = list(dict.fromkeys(dates))

senti=pd.to_numeric(News['compound']).groupby(News['Date']).mean()
dfn=pd.DataFrame(index=range(0,len(senti)),columns=['Date','compound'])
dfn['Date']=dates

tam=len(dfn)-1
for i in range(len(dfn)):
    dfn['compound'][i]=senti[tam]
    tam=tam-1

ticker ='VOO'

final_date=dfn['Date'][0] - timedelta(days=1)
initial_date=dfn['Date'][len(dfn)-1]+timedelta(days=1)

dfn=dfn.set_index('Date')
stock_data = web.DataReader(ticker, 'yahoo', initial_date, final_date)

# After downloading the data we calculate a value change and merge the snetiment of tweets with it

stock_data['stock_val_change'] = (stock_data['Close'] - stock_data['Open']) / stock_data['Open'] * 100.0
scaler = StandardScaler()
stock_data['stock_val_change_scaled'] = scaler.fit_transform(stock_data[['stock_val_change']])
dataset = pd.merge(stock_data[['Open', 'Volume','Adj Close','stock_val_change', 'stock_val_change_scaled']], dfn[['compound']], left_index=True, right_index=True)

# Adding the buy_sell indicator basing it on the val change

forecast_col = 'stock_val_change'
dataset['stock_val_change_pred'] = dataset[forecast_col].shift(-1)
dataset['buy_sell'] = dataset['stock_val_change_pred'].apply(lambda x: 1 if x >=0 else -1)

# We decide whta percentage of data we use for training and what for testing

trainper=int(len(dataset)*.75)
train_set = dataset.iloc[:trainper]
test_set = dataset.iloc[trainper:]

X_train = np.array(train_set[['compound']])
X_test = np.array(test_set[['compound']])

y_train = np.array(train_set['buy_sell'])
y_test = np.array(test_set['buy_sell'])

# Fitting our data

scaler = StandardScaler()
X_train_std= scaler.fit_transform(X_train)

# KNN ALGORITM

for i in range(1,5):
    knn = KNeighborsClassifier(n_neighbors=i).fit(X_train_std, y_train)
    y_test_pred = knn.predict(X_test)
    print(accuracy_score(y_test, y_test_pred))
      
knn = KNeighborsClassifier(n_neighbors=5).fit(X_train, y_train)
y_test_pred = knn.predict(X_test)

knn_list =[]
knn_list.append(y_test_pred)

# SVC 

for i in range(1,5):
    svc= SVC(kernel="linear", random_state=0, gamma=i)
    model= svc.fit(X_train_std, y_train)
    scores = cross_val_score(estimator=model, X=X_train_std, y=y_train, cv=4)
    print(i, ':', np.average(scores))

svc= SVC(kernel="rbf", random_state=0, gamma=3)
model= svc.fit(X_train_std, y_train)
y_test_pred = model.predict(X_test)

svmlist =[]
svmlist.append(y_test_pred)

# Decision Tree
# Cross-validation

decisiontree= DecisionTreeClassifier(max_depth=5)
model = decisiontree.fit(X_train_std, y_train)
y_test_pred = model.predict(X_test)

accuracy_score(y_test, y_test_pred)

# Add to the list

dtlist =[]
dtlist.append(y_test_pred)
print(X_train_std)

# Random Forest

randomforest = RandomForestClassifier(random_state=3, bootstrap=0, n_estimators=10000)

model=randomforest.fit(X_train_std, y_train)
y_test_pred = model.predict(X_test)

accuracy_score(y_test, y_test_pred)

# Add to the list

rflist = []
rflist.append(y_test_pred)

# logistic Regression
lr=LogisticRegression()
model = lr.fit(X_train_std, y_train)

# Calculate the accuracy score
y_test_pred = lr.predict(X_test)
print(metrics.accuracy_score(y_test,y_test_pred))

#Add to te list
lrlist=[]
lrlist.append(y_test_pred)

# Artificial Neural Network

# Finding the parameters to build the best net

for i in range(2,21):
    model4= MLPClassifier(hidden_layer_sizes=(i),max_iter=10000)
    scores= cross_val_score(estimator= model4, X=X_train_std, y=y_train, cv=4)
    print(i, '-', np.average(scores))

# Add to te list

mlp = MLPClassifier(hidden_layer_sizes=(4), max_iter=10000)
model = mlp.fit(X_train_std, y_train)
y_test_pred = model.predict(X_test)

annlist=[]
annlist.append(y_test_pred)

# Analyzing performance of models

outcome_df = pd.DataFrame({'Regular': y_test, 'KNN': knn_list[0], 'SVM': svmlist[0], 'Decision_Tree': dtlist[0], 'Random_Forest': rflist[0], 'Logistic': lrlist[0], 'ANN': annlist[0]})
predictions = pd.merge(dataset.iloc[trainper:].reset_index(), outcome_df, left_index=True, right_index = True)

# Analyzing geains or loss

predictions["Gain_or_Loss_KNN"] = (predictions['Adj Close'] - predictions['Open'])*predictions['KNN']
predictions["Gain_or_Loss_SVM"] = (predictions['Adj Close'] - predictions['Open'])*predictions['SVM']
predictions["Gain_or_Loss_DecisionTree"] = (predictions['Adj Close'] - predictions['Open'])*predictions['Decision_Tree']
predictions["Gain_or_Loss_Random_Forest"] = (predictions['Adj Close'] - predictions['Open'])*predictions['Random_Forest']
predictions["Gain_or_Loss_Logistic"] = (predictions['Adj Close'] - predictions['Open'])*predictions['Logistic']
predictions["Gain_or_Loss_ANN"] = (predictions['Adj Close'] - predictions['Open'])*predictions['ANN']

print("Predicciones",predictions.head())
first_day_result = predictions.iloc[0]['Adj Close']
predictions.at[ 0, 'KNN_Result']= first_day_result
predictions.at[ 0, 'LogReg_Result']= first_day_result
predictions.at[ 0, 'SVM_Result']= first_day_result
predictions.at[ 0, 'Naive_Bayes_Result']= first_day_result
predictions.at[ 0, 'Decision_Tree_Result']= first_day_result
predictions.at[ 0, 'Random_Forest_Result']= first_day_result
predictions.at[ 0, 'ANN_Result']= first_day_result

# Iterating trough the predictions

for i in range(1, len(predictions)):
    predictions.loc[i, 'KNN_Result'] = predictions.loc[i-1, 'KNN_Result'] + predictions.loc[i, 'Gain_or_Loss_KNN']
    predictions.loc[i, 'LogReg_Result'] = predictions.loc[i-1, 'LogReg_Result'] + predictions.loc[i, 'Gain_or_Loss_Logistic']
    predictions.loc[i, 'SVM_Result'] = predictions.loc[i-1, 'SVM_Result'] + predictions.loc[i, 'Gain_or_Loss_SVM']
    predictions.loc[i, 'Decision_Tree_Result'] = predictions.loc[i-1, 'Decision_Tree_Result'] + predictions.loc[i, 'Gain_or_Loss_DecisionTree']
    predictions.loc[i, 'Random_Forest_Result'] = predictions.loc[i-1, 'Random_Forest_Result'] + predictions.loc[i, 'Gain_or_Loss_Random_Forest']
    predictions.loc[i, 'ANN_Result'] = predictions.loc[i-1, 'ANN_Result'] + predictions.loc[i, 'Gain_or_Loss_ANN']

# Plotting the results
    
    #%matplotlib inline
plt.style.use('fivethirtyeight') 
plt.rcParams['figure.figsize'] = 25, 22 
plt.suptitle(ticker+" "+ str(initial_date)+" "+str(final_date), fontsize=30)

# Plotting our results

firstdata=predictions['Adj Close'][0]
ax1 = predictions['Adj Close']*(100/firstdata)
ax2 = predictions['KNN_Result']*(100/firstdata)
ax3 = predictions['LogReg_Result']*(100/firstdata)
ax4 = predictions['SVM_Result']*(100/firstdata)
ax5 = predictions['Decision_Tree_Result']*(100/firstdata)
ax6 = predictions['Random_Forest_Result']*(100/firstdata)
ax7 = predictions['ANN_Result']*(100/firstdata)

for i in range (1, 7):
    plt.subplots_adjust(hspace=0.6, wspace=0.15)
        
    plt.subplot(3,2,1)
    plt.plot(ax1, 'r',  linewidth=2)
    plt.plot(ax2,  'b',  linestyle=':', linewidth=5)
    plt.xlabel('Days', fontsize=20)
    plt.ylabel('Price', fontsize=20)
    plt.title('KNN',  fontsize=25)
    a='Buy-and-hold'
    b='KNN'
    plt.legend((a,b), fontsize=20, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=2, frameon=True)
    
    plt.subplot(3,2,2)
    plt.plot(ax1, 'r',  linewidth=2 )
    plt.plot(ax3, 'g',  linestyle=':', linewidth=5)
    plt.xlabel('Days', fontsize=20)
    plt.ylabel('Price', fontsize=20)
    plt.title('Logistic Regression', fontsize=25)
    a='Buy-and-hold'
    b='Log Reg'
    plt.legend((a,b), fontsize=20, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=2, frameon=True)
    
    plt.subplot(3,2,3)
    plt.plot(ax1, 'r',  linewidth=2 )
    plt.plot(ax4, 'c',  linestyle=':', linewidth=5)
    plt.xlabel('Days', fontsize=20)
    plt.ylabel('Price', fontsize=20)
    plt.title('SVM', fontsize=25)
    a='Buy-and-hold'
    b='SVM'
    plt.legend((a,b), fontsize=20, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=2, frameon=True)
    
    plt.subplot(3,2,4)
    plt.plot(ax1, 'r',  linewidth=2 )
    plt.plot(ax5, 'm',  linestyle=':', linewidth=5)
    plt.xlabel('Days', fontsize=20)
    plt.ylabel('Price', fontsize=20)
    plt.title('Decision Tree', fontsize=25)
    a='Buy-and-hold'
    b='Decision Tree'
    plt.legend((a,b), fontsize=20, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=2, frameon=True)
    
    plt.subplot(3,2,5)
    plt.plot(ax1, 'r',  linewidth=2 )
    plt.plot(ax6, 'royalblue',  linestyle=':', linewidth=5)
    plt.xlabel('Days', fontsize=20)
    plt.ylabel('Price', fontsize=20)
    plt.title('Random Forest', fontsize=25)
    a='Buy-and-hold'
    b='Random Forest'
    plt.legend((a,b), fontsize=20, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=2, frameon=True)
    
    plt.subplot(3,2,6)
    plt.plot(ax1, 'r',  linewidth=2 )
    plt.plot(ax7, 'saddlebrown',  linestyle=':', linewidth=5)
    plt.xlabel('Days', fontsize=20)
    plt.ylabel('Price', fontsize=20)
    plt.title('Artificial Neural Network', fontsize=25)
    a='Buy-and-hold'
    b='ANN'
    plt.legend((a,b), fontsize=20, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=2, frameon=True)

# pylab.savefig('AAL.jpg') # Saves figure as .jpg-file

plt.show()

# References

'https://towardsdatascience.com/can-we-beat-the-stock-market-using-twitter-ef8465fd12e2'
'https://www.kaggle.com/therohk/million-headlines'