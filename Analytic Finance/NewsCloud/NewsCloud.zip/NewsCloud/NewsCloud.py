
# NewsCloud

"""
The objective of this code is to get news from different newspapers and create a word cloud.
"""

# Libraries

from selenium import webdriver
import time
from datetime import date
import openpyxl
from pathlib import Path
from webdriver_manager.chrome import ChromeDriverManager
import pathlib
from bs4 import BeautifulSoup as BS
import requests
import docx
from datetime import datetime, timedelta
from docx2pdf import  convert
import numpy as np
from docx.shared import Pt

rutac=pathlib.Path(__file__).parent.absolute()
rutac=str(rutac)
print(rutac)

FECHAHOY=date.today()
FECHAHOY=str(FECHAHOY)
FECHAA=date.today()- timedelta(days=1)
FECHAA=str(FECHAA)

wd = webdriver.Chrome(ChromeDriverManager().install())
wait_imp = 4
CO = webdriver.ChromeOptions()
CO.add_experimental_option('useAutomationExtension', False)
CO.add_argument('--ignore-certificate-errors')
CO.add_argument('--start-minimized')

#CO.add_argument('--proxy-server=46.102.106.37:13228')
#browser = webdriver.Chrome(executable_path=(r'C:\Users\980006499\Desktop\Proyecto\chromedriver.exe'), chrome_options=CO)
wd.implicitly_wait(wait_imp)
FS=FECHAHOY.split("-")
day=FS[2]
mon=FS[1]
ye=FS[0]

wd.implicitly_wait(wait_imp)

# Search LPO Global

contador=0
wd.get("https://www.lapoliticaonline.com.mx/seccion/internacionales/")
time.sleep(3)
response= requests.get("https://www.lapoliticaonline.com.mx/seccion/internacionales/")
sopa = BS(response.content,"html.parser")
sopa.prettify
time.sleep(5)
divs=sopa.find_all('div', {'class': 'items'})
docp=docx.Document()
linea=""
for news in divs:
    contador=contador+1
    if contador<15:
        print(news.text)
        linea=news.text
        linea=linea.replace('\r', '').replace('\n', '')
        docp.add_paragraph(news.text)
docp.save(rutac+"\\NoticiasGlob\\LPOG_"+FECHAHOY+".docx")
convert(rutac+"\\NoticiasGlob\\LPOG_"+FECHAHOY+".docx",rutac+"\\NoticiasGlob\\LPOG_"+FECHAHOY+".pdf")

# Search WSJ Global

doc=docx.Document()
wd.get("https://www.wsj.com/search?query=&isToggleOn=true&operator=AND&sort=date-desc&duration=2d&startDate="+ye+"%2F"+mon+"%2F"+str(int(day)-2)+"&endDate="+ye+"%2F"+mon+"%2F"+day+"&source=wsjie%2Cwsjsitesrch%2Cwsjpro&page=2")
time.sleep(3)

linea=""
xpa="/html/body"

elem = wd.find_element_by_xpath(xpa)

all_li = elem.find_elements_by_tag_name("h3")
CUENTA=0
time.sleep(3)
wd.execute_script("window.scrollTo(0, document.body.scrollHeight);")

for li in all_li:
    if CUENTA<len(all_li)-10:
        print(li.text)
    
        linea= li.text

        doc.add_paragraph(linea)
        CUENTA=CUENTA+1
rang=np.arange(7)
CUENTA=0   
for j in range(len(rang)):

    wd.get("https://www.wsj.com/search?query=&isToggleOn=true&operator=AND&sort=date-desc&duration=2d&startDate="+ye+"%2F"+mon+"%2F"+str(int(day)-2)+"&endDate="+ye+"%2F"+mon+"%2F"+day+"&source=wsjie%2Cwsjsitesrch%2Cwsjpro&page="+str(j+2))
    
    linea=""
    
    elem = wd.find_element_by_xpath(xpa)
    
    all_li = elem.find_elements_by_tag_name("h3")
    CUENTA=0
    time.sleep(7)
    wd.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    
    for li in all_li:
        if CUENTA<len(all_li)-10:
            print(li.text)
            linea= li.text

            doc.add_paragraph(linea)
            CUENTA=CUENTA+1

doc.save(rutac+"\\NoticiasGlob\WSJG_"+FECHAHOY+".docx")
convert(rutac+"\\NoticiasGlob\\WSJG_"+FECHAHOY+".docx",rutac+"\\NoticiasGlob\\WSJG_"+FECHAHOY+".pdf")

# Searhc Reuters Global

wd.get("https://www.reuters.com/news/archive/worldnews")
time.sleep(3)
response= requests.get("https://www.reuters.com/news/archive/worldnews")
sopa = BS(response.content,"html.parser")
sopa.prettify

time.sleep(5)
divs=sopa.find_all('div', {'class': 'story-content'})
doc1=docx.Document()
linea=""
for news in divs:
    print(news.text)
    linea=news.text
    linea=linea.replace('\r', '').replace('\n', '')
    doc1.add_paragraph(news.text)
doc1.save(rutac+"\\NoticiasGlob\\REUTG_"+FECHAHOY+".docx")
convert(rutac+"\\NoticiasGlob\\REUTG_"+FECHAHOY+".docx",rutac+"\\NoticiasGlob\\REUTG_"+FECHAHOY+".pdf")

rutac=pathlib.Path(__file__).parent.absolute()
rutac=str(rutac)
print(rutac)

FECHAHOY=date.today()
FECHAHOY=str(FECHAHOY)
doc=docx.Document()
wd = webdriver.Chrome(ChromeDriverManager().install())
wait_imp = 4
CO = webdriver.ChromeOptions()
CO.add_experimental_option('useAutomationExtension', False)
CO.add_argument('--ignore-certificate-errors')
CO.add_argument('--start-minimized')

# CO.add_argument('--proxy-server=46.102.106.37:13228')
# browser = webdriver.Chrome(executable_path=(r'C:\Users\980006499\Desktop\Proyecto\chromedriver.exe'), chrome_options=CO)

wd.implicitly_wait(wait_imp)

#In each "Search" we take a unique part of the webpages and the generalized data we van use to surf trough the data better

# Search WSJ Mexico

doc=docx.Document()
wd.get("https://www.wsj.com/search?query=Mexico&isToggleOn=true&operator=AND&sort=date-desc&duration=2d&startDate="+ye+"%2F"+mon+"%2F"+str(int(day)-2)+"&endDate="+ye+"%2F"+mon+"%2F"+day+"&source=wsjie%2Cwsjsitesrch%2Cwsjpro&page=2")
time.sleep(3)

linea=""
xpa="/html/body"

elem = wd.find_element_by_xpath(xpa)
#we find all the headlines
all_li = elem.find_elements_by_tag_name("h3")
CUENTA=0
time.sleep(3)
wd.execute_script("window.scrollTo(0, document.body.scrollHeight);")

for li in all_li:
    if CUENTA<len(all_li)-10:
        print(li.text)
        linea= li.text
        doc.add_paragraph(linea)
        CUENTA=CUENTA+1
rang=np.arange(7)
CUENTA=0   
#we go back 7 times because thats in average one day in the page
for j in range(len(rang)):

    wd.get("https://www.wsj.com/search?&query=mexico&mod=searchresults_viewallresults")
    
    linea=""
    
    elem = wd.find_element_by_xpath(xpa)
    
    all_li = elem.find_elements_by_tag_name("h3")
    CUENTA=0
    time.sleep(4)

    for li in all_li:
        if CUENTA<len(all_li)-10:
            print(li.text)
            linea= li.text

            doc.add_paragraph(linea)
            CUENTA=CUENTA+1

doc.save(rutac+"\\Noticias\WSJ_"+FECHAHOY+".docx")
convert(rutac+"\\Noticias\\WSJ_"+FECHAHOY+".docx",rutac+"\\Noticias\\WSJ_"+FECHAHOY+".pdf")

# Serach Reuters Mexico

wd.get("https://www.reuters.com/search/news?blob=Mexico&sortBy=date&dateRange=pastDay")
time.sleep(3)
response= requests.get("https://www.reuters.com/search/news?blob=Mexico&sortBy=date&dateRange=pastDay")
sopa = BS(response.content,"html.parser")
sopa.prettify

time.sleep(3)
masresul=wd.find_element_by_xpath('//*[@id="content"]/section[2]/div/div[1]/div[4]/div/div[4]/div[1]')
masresul.click()

#In this search is easier because all the new are in divs with the same class without repetition the class is a group but their elements are uniquely apart
time.sleep(5)
divs=sopa.find_all('div', {'class': 'search-result-indiv'})
doc2=docx.Document()
linea=""
for news in divs:
    print(news.text)
    linea=news.text
    linea=linea.replace('\r', '').replace('\n', '')
    doc2.add_paragraph(news.text)
doc2.save(rutac+"\\Noticias\\REUT_"+FECHAHOY+".docx")
convert(rutac+"\\Noticias\\REUT_"+FECHAHOY+".docx",rutac+"\\Noticias\\REUT_"+FECHAHOY+".pdf")

# Search LPO Mexico

#In this seach all of our news are also easier to get beacuse they diferntiate a lot from the others elements in the webpage

wd.get("https://www.lapoliticaonline.com.mx/")
time.sleep(3)
response= requests.get("https://www.lapoliticaonline.com.mx/")
sopa = BS(response.content,"html.parser")
sopa.prettify
time.sleep(5)
divs=sopa.find_all('div', {'class': 'item'})
doc3=docx.Document()
linea=""
for news in divs:
    print(news.text)
    linea=news.text
    linea=linea.replace('\r', '').replace('\n', '')
    doc3.add_paragraph(news.text)
doc3.save(rutac+"\\Noticias\\LPO_"+FECHAHOY+".docx")
convert(rutac+"\\Noticias\\LPO_"+FECHAHOY+".docx",rutac+"\\Noticias\\LPO_"+FECHAHOY+".pdf")

# Libraries Word Cloud

import re
import nltk
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
import pathlib
import fitz  #PyMuPDF
from wordcloud import WordCloud
from datetime import date
plt.rcParams['figure.figsize'] = [5,4]
#nltk.download('punkt')

FECHAHOY=date.today()
FECHAHOY=str(FECHAHOY)
#We save names of each groups of news we got
list_name=['WSJG_'+FECHAHOY,'REUTG_'+FECHAHOY,'LPOG_'+FECHAHOY]
rutac=pathlib.Path(__file__).parent.absolute()
rutac=str(rutac)
rutac=rutac+"\\NoticiasGlob\\"
print(rutac)
for i in range(len(list_name)):
    name = list_name[i]
    
    doc = fitz.open(rutac+name+".pdf")
    
    print(rutac+name+".pdf")
    Paragraph = ''
    for pag in doc:
        Paragraph += pag.getText()

    # Cleaning Text
    
    #Min Cap
    
    formated_p = Paragraph.lower()
        
    #Remove accents
    formated_p = re.sub(r'ñ','n', formated_p)
    formated_p = re.sub(r'Ñ','n', formated_p)
    
    formated_p = re.sub(r'á','a', formated_p)
    formated_p = re.sub(r'Á','a', formated_p)
    
    formated_p = re.sub(r'é','e', formated_p)
    formated_p = re.sub(r'É','e', formated_p)
    
    formated_p = re.sub(r'ó','o', formated_p)
    formated_p = re.sub(r'Ó','o', formated_p)
    
    formated_p = re.sub(r'ú','u', formated_p)
    formated_p = re.sub(r'Ú','u', formated_p)
    
    formated_p = re.sub(r'í','i', formated_p)
    formated_p = re.sub(r'Í','i', formated_p)
    
    formated_p = re.sub(r':','.', formated_p)
    formated_p = re.sub(r';','.', formated_p)
    
    #Take phrases and cleans
    sentence_list = nltk.sent_tokenize(formated_p)

    formated_p = re.sub(r'\W',' ',formated_p)

    formated_p = re.sub(r'[^a-zA-Z]', ' ', formated_p)

    formated_p = re.sub(r'\s+',' ', formated_p, flags=re.I)

    formated_p = re.sub(r'^b\s+',' ',formated_p)

    formated_p = re.sub(r'\s+[a-zA-Z]\s+',' ', formated_p)
    
    #Words we dont want to include in the counting
    stopwords = ['in','into','podemos','busca','despues','nice','est','why','hace','solo','happening','hacer','set','still','sera','lpoes','billion','people','covid','through','casi','tambien','pidio','cases','pe','news','since','apuntan','dias','situacion','down','death','gain','top','back','world','diputado','larreta','plata','alberto','macri','auto','five','future','stocks','markets','not','magazine','cambiemos','just','ahead','fed','covering','roundup','stock','talk','talks','market','latest','heard','exclusivo','wednesday','million','etthe','their','ante','case','board','tech','yields','newsplus','opinion','business','editorial','hours','review','would','outlook','review','agothe','contagios','pandemic','andrew','wallace','hour','prices','than','coronavirus','company','newsletter','reports','time','price','home','close','high','up','its','ago','min','an','casos','ciudad','habia','et','sunday','over','empresa','todo','si','mil','as','eta','ex','appeared','edition','WSJ','pro','pandemia','anuncio','contagio','needed','year','print','quiere','gobierno','president','week','saturday','country','le','millones','provincia','monday','new','near','after','friday','tuesday','wednesdau','thursday','will','hasta','pese','pais','acelera','lpola','este','in','lpoel','in', 'hay', 'The','am','says','reporting', 'pm','on','reuters','city','edt','el', 'in', 'and', 'is', 'of', 'del', 'se', 'for', 'at',
                  'a', 'for', 'with', 'no', 'a', 'your', 'at', 'it', 'like', 'more', 'but',
                  'your', 'you', 'already', 'or', 'this', 'yes', 'because', 'this', 'between', 'when',
                  'very', 'without', 'about', 'also', 'me', 'to', 'there', 'where', 'who',
                  'from', 'all', 'us', 'during', 'all', 'one', 'them', 'nor', 'against',
                  'some', 'what', 'some', 'me', 'other', 'other', 'other', 'he', 'both',
                  'that', 'these', 'a lot', 'who', 'nothing', 'many', 'which', 'little',
                  'she', 'be', 'these', 'some', 'something', 'us', 'my', 'my',
                  'you', 'you', 'you', 'you', 'your', 'they', 'us', 'you',
                  'you', 'you', 'mine', 'mine', 'mine', 'mine', 'yours', 'yours', 'yours',
                  'yours', 'his', 'his', 'his', 'his', 'our', 'our',
                  'our', 'our', 'yours', 'yours', 'yours', 'yours',
                  'those', 'those', 'I am', 'you are', 'there', 'we are', 'you are', 'they are',
                  'be', 'you are', 'we are', 'you are', 'be', 'I will be', 'you will be',
                  'will be', 'will be', 'will be', 'will be', 'would be', 'would be',
                  'would be', 'would be', 'would be', 'was', 'you were',
                  'we were', 'you were', 'you were', 'I was', 'you were', 'you were',
                  'we were', 'you were', 'they were', 'you were', 'you were',
                  'we were', 'you were', 'you were', 'you were',
                  'were', 'were', 'were', 'were', 'being',
                  'state', 'state', 'states', 'states', 'stay', 'he', 'has', 'ha',
                  'we have', 'you have', 'han', 'haya', 'beech', 'we have', 'you have', 'have',
                  'there will be', 'there will be', 'there will be', 'we will', 'there will be', 'there will be', 'there will be',
                  'would have', 'would have', 'would have', 'would have', 'had', 'had',
                  'had', 'had', 'had', 'had', 'had', 'had', 'had',
                  'would have', 'would have', 'would have', 'would have', 'would have',
                  'would have', 'would have', 'would have', 'would have', 'would have',
                  'would have', 'would have', 'having', 'had', 'had', 'had',
                  'habidas', 'I am', 'you are', 'is', 'we are', 'you are', 'are', 'sea', 'you are',
                  'let us be', 'be you', 'be', 'I will be', 'you will be', 'will be', 'we will be', 'you will be',
                  'will be', 'would be', 'would be', 'would be', 'would you be', 'would be', 'was',
                  'You were', 'We were', 'You were', 'You were', 'I was', 'You were', 'It was', 'We were',
                  'you were', 'you were', 'you were', 'you were', 'we were', 'you were',
                  'were', 'were', 'were', 'we were', 'were', 'were',
                  'feeling', 'felt', 'felt', 'senses', 'felt', 'feels',
                  'feel', 'have', 'have', 'have', 'have', 'have', 'have',
                  'have', 'have', 'lets have', 'have', 'have', 'will have', 'will have',
                  'will have', 'will have', 'will have', 'will have', 'would have', 'would have',
                  'would have', 'would have', 'would have', 'had', 'had', 'we had',
                  'had', 'had', 'had', 'had', 'had', 'had', 'had',
                  'had', 'had', 'would have', 'would have', 'would have',
                  'had', 'had', 'had', 'we had', 'had',
                  'had', 'having', 'had', 'had', 'had', 'had', 'had']
    
    stopwords2 = ['e', 'c', 'f', '\ n', 'bank', 't', 'j', 'i', 'ii', 'iii', 'n', 'l', 'd',
                    'm', 'a', 'graph', 'January', 'February', 'March', 'April', 'May',
                    'June', 'Exico', 'July', 'August', 'September', 'October',
                    'November', 'December', 'Jan', 'Feb', 'Tue', 'Apr', 'May', 'Jun',
                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Annual', 'Report',
                    'quarterly', 'source', 'exico', 'quarter', 'source', 'mexico',
                    'line', 'quarters', 'sources', 'balances', 'uses',
                    'available information', 'determinants', 'including',
                    'available', 'information', 'process', 'solid', 'dotted',
                    'erepresenta', 'first', 'underlying', 'media', 'mobile', 'trim',
                    'general', 'frame', 'previous', 'current', 'fan', 'by', 'cent',
                    'p', 'pp', 'determination', 'u', 'v', 'h', 'g', 'z', 'r', 'k', 'y', 'o',
                    'aa', 'aaa', 'also', 'ank', 'anus', 'years', 'approximately', 'arzo',
                    'thus', 'likewise', 'even', 'although', 'joined', 'b', 'fits', 'each', 'give',
                    'dara', 'say', 'day', 'days', 'bliss', 'said', 'said', 'said',
                    'gave', 'twelve', 'two', 'three', 'it', 'embargo', 'date', 'have',
                    'had', 'had', 'having', 'done', 'done', 'towards', 'done',
                    'did', 'include', 'even', 'include', 'start', 'initially',
                    'start', 'iv', 'jp', 'place', 'sample', 'nero', 'obvious', 'seems',
                    'weigh', 'weigh', 's', 'section', 'according to', 'second', 'second', 'six',
                    'if', 'been', 'but', 'such', 'total', 'totals', 'translate', 'translate',
                    'cross', 'united', 'only', 'x', 'bb', 'bbb', 'bbc', 'bc', 'bce',
                    'bea', 'bls', 'cbp', 'ccm', 'cds', 'behavior', 'carries',
                    'consequence', 'context', 'contrast', 'corresponding',
                    'corresponding', 'which', 'any', 'how much', 'quarter',
                    'four', 'curve', 'curves', 'data', 'data', 'must', 'due',
                    'various', 'various', 'effect', 'effects', 'axis', 'example',
                    'exercise', 'exercise', 'elaboration', 'elaborated', 'elaborated',
                    'elaborated', 'found', 'survey', 'respondents', 'surveys',
                    'er', 'final', 'final', 'graphic', 'historically', 'historical',
                    'imor', 'imora', 'interval', 'intervals', 'way', 'month', 'months',
                    'note', 'note', 'notes', 'observe', 'observation', 'observations',
                    'observed', 'observed', 'observed', 'observed', 'observed',
                    'observing', 'observing', 'observing', 'observing', 'observing',
                    'nevertheless', 'depart', 'past', 'passing', 'passing', 'passing',
                    'period', 'periods', 'could', 'could', 'previously', 'revias',
                    'previous', 'previous', 'q', 'fortnight', 'fortnightly', 'box',
                    'reference', 'referenced', 'references', 'referred', 'referred',
                    'referrals', 'refers', 'refer', 'rebound', 'rebounded',
                    'rebound', 'rebound', 'respect', 'respectively', 'respective',
                    'respect', 'acronym', 'system', 'such', 'window', 'sales', 'view',
                    'vi', 'vias', 'www', 'third', 'part', 'w', 'ma', 'particular',
                    'particular', 'ea', 'oea', 'abcd', 'presumably', 'conceptual',
                    'central', 'mexican', 'same', 'particularly', 'public', 'today',
                    'query', 'publishes', 'out', 'concepts', 'relation', 'compliant',]

    stopwords3=['en','un','pero','dijo','ahora','am','sus','ano','dia','edt','con','lpo','que','esta','que','lo','los','que','por','lo','al','las','la','como','una', 'mas','el', 'El', 'el', 'en', 'y', 'es', 'de', 'del', 'se', 'para', 'en',
                  'a', 'for', 'with', 'no', 'a', 'your', 'at', 'it', 'like', 'more', 'but',
                  'tu', 'tú', 'ya', 'o', 'esto', 'sí', 'porque', 'esto', 'entre', 'cuando',
                  'muy', 'sin', 'sobre', 'también', 'yo', 'a', 'allí', 'dónde', 'quién',
                  'desde', 'todos', 'nosotros', 'durante', 'todos', 'uno', 'ellos', 'ni', 'contra',
                  'algunos', 'qué', 'algunos', 'yo', 'otro', 'otro', 'otro', 'él', 'ambos',
                  'eso', 'estos', 'mucho', 'quién', 'nada', 'muchos', 'cuál', 'pequeño',
                  'ella', 'ser', 'estos', 'algunos', 'algo', 'nosotros', 'mi', 'mi',
                  'usted', 'usted', 'usted', 'usted', 'su', 'ellos', 'nosotros', 'usted',
                  'tú', 'tú', 'mío', 'mío', 'mío', 'mío', 'tuyo', 'tuyo', 'tuyo',
                  'tuyo', 'su', 'su', 'su', 'su', 'nuestro', 'nuestro',
                  'nuestro', 'nuestro', 'tuyo', 'tuyo', 'tuyo', 'tuyo',
                  'esos', 'esos', 'yo soy', 'tú estás', 'allí', 'nosotros somos', 'tú eres', 'ellos son',
                  'ser', 'tú eres', 'nosotros', 'tú eres', 'ser', 'yo seré', 'tú serás',
                  'será', 'será', 'será', 'será', 'sería', 'sería',
                  'sería', 'sería', 'sería', 'fue', 'tú eras',
                  'nosotros éramos', 'tú eras', 'tú eras', 'yo era', 'tú eras', 'tú eras',
                  'nosotros éramos', 'tú eras', 'ellos eran', 'tú eras', 'tú eras',
                  'éramos', 'eras', 'eras', 'eras',
                  'fueron', 'fueron', 'fueron', 'fueron', 'siendo',
                  'estado', 'estado', 'estados', 'estados', 'permanecer', 'él', 'tiene', 'ha',
                  'tenemos', 'tienes', 'han', 'haya', 'haya', 'tenemos', 'tienes', 'has',
                  'habrá', 'habrá', 'habrá', 'nosotros', 'habrá', 'habrá', 'habrá',
                  'tendría', 'tendría', 'tendría', 'tendría', 'tendría', 'tendría',
                  'tenía', 'tenía', 'tenía', 'tenía', 'tenía', 'tenía', 'tenía',
                  'tendría', 'tendría', 'tendría', 'tendría', 'tendría',
                  'tendría', 'tendría', 'tendría', 'tendría', 'tendría',
                  'tendría', 'tendría', 'teniendo', 'tenía', 'tenía', 'tenía',
                  'habidas', 'yo soy', 'tu eres', 'es', 'nosotros somos', 'tu eres', 'eres', 'mar', 'tu eres',
                  'déjanos ser', 'sé tú', 'sé', 'yo seré', 'tú serás', 'serás', 'nosotros seremos', 'tú serás',
                  'será', 'sería', 'sería', 'sería', 'usted sería', 'sería', 'fue',
                  'Tú eras', 'Nosotros éramos', 'Tú eras', 'Tú eras', 'Yo era', 'Tú eras', 'Era', 'Nosotros éramos',
                  'eras', 'eras', 'eras', 'eras', 'fuimos', 'eras',
                  'éramos', 'éramos', 'éramos', 'éramos', 'éramos', 'éramos',
                  'sentimiento', 'sentí', 'sentí', 'sentidos', 'sentí', 'siente',
                  'sentir', 'tener', 'tener', 'tener', 'tener', 'tener', 'tener',
                  'tener', 'tener', 'vamos a tener', 'tener', 'tener', 'tendremos', 'tendremos',
                  'tendrá', 'tendrá', 'tendrá', 'tendrá', 'tendría', 'tendría',
                  'tendría', 'tendría', 'tendría', 'tenía', 'tenía', 'teníamos',
                  'tenía', 'tenía', 'tenía', 'tenía', 'tenía', 'tenía', 'tenía',
                  'tenía', 'tenía', 'tendría', 'tendría', 'tendría',
                  'tenía', 'tenía', 'tenía', 'teníamos', 'tenía',
                  'tenía', 'teniendo', 'tenía', 'tenía', 'tenía', 'tenía', 'tenía']
    
    stopwords = stopwords + stopwords2+ stopwords3
    
    #Empty dict
    word_freq = {}
    
    # Token & Stopwords
    
    for word in nltk.word_tokenize(formated_p):
        #si la palabra no esta en stopwords
        
        if word not in stopwords: 

            if word not in word_freq.keys():
                #Add word to dthe dict
                word_freq[word] = 1

            else:      

                word_freq[word] +=1
    
    dw = pd.DataFrame(data=word_freq, index=[0])
    dw = (dw.T)
    
    # Scoring words
    maxi = max(list(word_freq.values()))
    
    # Scoring each linea
    
    sentence_scr = {}
    
    for sentenc in sentence_list:
        #
        formated_s = re.sub('[^a-zA-Z]', ' ', sentenc)
      
        #lowers
        formated_s = formated_s.lower()
        for word in nltk.word_tokenize(formated_s):
            
            if word not in stopwords:

                if len(sentenc.split(' '))<45:

                    if sentenc not in sentence_scr.keys():
                        #adds the word with the frequence of the first encountered word
                        sentence_scr[sentenc] = word_freq[word]/maxi
        
                    else:
                        #Scores
                        sentence_scr[sentenc] += word_freq[word]/maxi
    

    Frases = pd.DataFrame(data={})

    Frases["Sentence"] = list(sentence_scr.keys())

    Frases["Score"] = sentence_scr.values()
    Frases["Score"] = Frases["Score"]

    Frases = Frases.sort_values(by='Score',ascending=False)

    print(Frases)
    Frases = Frases*1
    Frases.to_excel("ResultadosGlob\\"+name + "_Con_filtro.xlsx")
    
    wc = WordCloud(stopwords=stopwords, background_color="white", colormap="Dark2",
                    max_font_size=150, random_state=42)

    wc.generate(formated_p)

    plt.imshow(wc, interpolation="bilinear")
    plt.axis("off")
    name_img = "ResultadosGlob\\World cloud"+name+".png"
    plt.savefig(name_img)
    plt.title(i)
    plt.show()

FECHAHOY=date.today()
FECHAHOY=str(FECHAHOY)

list_name=['WSJ_'+FECHAHOY,'REUT_'+FECHAHOY,'LPO_'+FECHAHOY]
rutac=pathlib.Path(__file__).parent.absolute()
rutac=str(rutac)
rutac=rutac+"\\Noticias\\"
print(rutac)
for i in range(len(list_name)):
    name = list_name[i]
    
    doc = fitz.open(rutac+name+".pdf")
    print(doc.metadata, '\n')
    Paragraph = ''
    for pag in doc:
        Paragraph += pag.getText()
    print(Paragraph)
    
    # Cleaning text  
  
    formated_p = Paragraph.lower()
    
    formated_p = re.sub(r'ñ','n', formated_p)
    formated_p = re.sub(r'Ñ','n', formated_p)
    
    formated_p = re.sub(r'á','a', formated_p)
    formated_p = re.sub(r'Á','a', formated_p)
    
    formated_p = re.sub(r'é','e', formated_p)
    formated_p = re.sub(r'É','e', formated_p)
    
    formated_p = re.sub(r'ó','o', formated_p)
    formated_p = re.sub(r'Ó','o', formated_p)
    
    formated_p = re.sub(r'ú','u', formated_p)
    formated_p = re.sub(r'Ú','u', formated_p)
    
    formated_p = re.sub(r'í','i', formated_p)
    formated_p = re.sub(r'Í','i', formated_p)
    
    formated_p = re.sub(r':','.', formated_p)
    formated_p = re.sub(r';','.', formated_p)
    
    sentence_list = nltk.sent_tokenize(formated_p)

    formated_p = re.sub(r'\W',' ',formated_p)

    formated_p = re.sub(r'[^a-zA-Z]', ' ', formated_p)
    
    formated_p = re.sub(r'\s+',' ', formated_p, flags=re.I)

    formated_p = re.sub(r'^b\s+',' ',formated_p)

    formated_p = re.sub(r'\s+[a-zA-Z]\s+',' ', formated_p)
    
    stopwords = stopwords + stopwords2+ stopwords3
    
    word_freq = {}
    
    # Token & stopwords

    for word in nltk.word_tokenize(formated_p):

        if word not in stopwords: 

            if word not in word_freq.keys():

                word_freq[word] = 1
            
            else:      
                #suma uno
                word_freq[word] +=1
    
    dw = pd.DataFrame(data=word_freq, index=[0])
    dw = (dw.T)
    
    # Scoring words
    maxi = max(list(word_freq.values()))
    
    # Scoring each linea
    
    sentence_scr = {}
    
    for sentenc in sentence_list:

        formated_s = re.sub('[^a-zA-Z]', ' ', sentenc)

        formated_s = formated_s.lower()
        for word in nltk.word_tokenize(formated_s):

            if word not in stopwords:

                if len(sentenc.split(' '))<45:

                    if sentenc not in sentence_scr.keys():

                        sentence_scr[sentenc] = word_freq[word]/maxi

                    else:

                        sentence_scr[sentenc] += word_freq[word]/maxi
    
    Frases = pd.DataFrame(data={})

    Frases["Sentence"] = list(sentence_scr.keys())

    Frases["Score"] = sentence_scr.values()
    Frases["Score"] = Frases["Score"]

    Frases = Frases.sort_values(by='Score',ascending=False)

    print(Frases)
    Frases = Frases*1
    Frases.to_excel("Resultados\\"+name + "_Con_filtro.xlsx")

    wc = WordCloud(stopwords=stopwords, background_color="white", colormap="Dark2",
                    max_font_size=150, random_state=42)

    wc.generate(formated_p)

    plt.imshow(wc, interpolation="bilinear")
    plt.axis("off")
    name_img = "Resultados\\World cloud"+name+".png"
    plt.savefig(name_img)
    plt.title(i)
    plt.show()

# References

'https://www.crummy.com/software/BeautifulSoup/bs4/doc/'
'https://www.selenium.dev/selenium/docs/api/py/api.html'