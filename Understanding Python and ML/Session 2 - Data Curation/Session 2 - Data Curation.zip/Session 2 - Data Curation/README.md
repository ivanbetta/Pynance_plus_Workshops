
Redy to run!

For instructions please check this video: https://www.youtube.com/watch?v=fmksRNitzVI&feature=youtu.be and Data Curation pdf

Enjoy!
