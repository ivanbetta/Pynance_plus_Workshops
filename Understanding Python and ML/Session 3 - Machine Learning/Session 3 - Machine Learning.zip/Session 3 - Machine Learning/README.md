
Redy to run!

For instructions please check this video: https://www.youtube.com/watch?v=kZAosZwnnnA and Machine Learning pdf

Enjoy!
